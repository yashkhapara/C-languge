#include<stdio.h>
void main()
{
    int a,b;

    printf("enter the value of a= ");
    scanf("%d",&a);
    // printf("enter the value of b= ");
    // scanf("%d",&b);
    b=a*a;
    printf("Square of  numbers= %d\n",b);
}