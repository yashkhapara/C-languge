#include<stdio.h>
void main()
{
    int a,b,c;

    printf("enter the value of a= ");
    scanf("%d",&a);
    printf("enter the value of b= ");
    scanf("%d",&b);
    c=a*b;
    printf("Multiplication of three numbers= %d\n",c);
}