#include<stdio.h>
void main()
{
	int l=130;
	int a=l*4;

	printf("the calculate  perimeter of a squre = %d",a);

}