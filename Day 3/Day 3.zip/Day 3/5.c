#include<stdio.h>
void main()
{
   int a,b,c,d;

   a=50;
   b=20;
   c=30;
   d=a+b+c;

   printf("The addition of three number = %d\n",d);
}