#include<stdio.h>
void main()
{
	int a,b,c,d,e;

	a=c =3;
	b=d =2;

	e=2*(a+b);

	printf(" the calculate  perimeter of a rectangle = %d",e);
}