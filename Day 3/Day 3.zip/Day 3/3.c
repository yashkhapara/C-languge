#include<stdio.h>
void main()
{
   int a,b,c;

   a=50;
   b=20;
   c=a+b;

   printf("The addition of two number = %d\n",c);
}