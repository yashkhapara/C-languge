#include<stdio.h>
void main()
{
	int a,b;

	a=24;
	b=a*a;

	printf("The area of a  square = %d",b);
}