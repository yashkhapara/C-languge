#include<stdio.h>
void main()
{
	int h,w,a;
  
    h=30;
    w=20;

	a=h*w ;

	printf("The area of a rectangle =%d",a);
}