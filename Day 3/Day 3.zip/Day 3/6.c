#include<stdio.h>
void main()
{
   int a,b,c,d,e;

   a=5;
   b=2;
   c=3;
   d=5;
   e=a*b*c*d;

   printf("The multiplication of four number = %d\n",e);
}