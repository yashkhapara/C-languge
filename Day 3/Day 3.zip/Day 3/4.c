#include<stdio.h>
void main()
{
   int a,b,c;

   a=12;
   b=4;
   c=a/b;

   printf("The divison of two number = %d\n",c);
}