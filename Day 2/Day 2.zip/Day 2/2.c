#include<stdio.h>
void main()
{
	printf("- - - - - - - - - \n");
	printf("|               | \n");
	printf("R               | \n");
	printf("N               | \n");
	printf("W               | \n");
	printf("|               | \n");
	printf("- - - - - - - - - \n");
}