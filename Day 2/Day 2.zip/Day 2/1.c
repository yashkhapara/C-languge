#include <stdio.h>
void main()
{
	printf("*****************************************************************\n*\t\t\t\t\t\t\t\t*\n");
	printf("*\tName   :- Khapara Yash Pravinbhai.\t\t\t*\n");
	printf("*\tAge    :- 19 years old.\t\t\t\t\t*\n");
	printf("*\tSchool :- Red and White Multimedia Education. \t\t*\n*\t\t\t\t\t\t\t\t*\n");
	printf("*****************************************************************\n");
}