#include<stdio.h>
void main()
{
	printf("**\n");
	printf("**\n");
	printf("**\n");
	printf("**\n");
	printf("**                     **\n");
	printf("**                    **\n");
	printf("**      **           **\n");
	printf("**     ** **        **\n");
	printf("**    **   **      **\n");
	printf("**   **     **    **\n");
    printf("**  **       ** **\n");
	printf("** **\n");
	printf("**\n");
}