#include<stdio.h>
void main()
{
    int a,b,c;
    printf("enter the value:");
    scanf("%d%d",&a,&b);
  c=a+b;
    printf("avg of value :%d",c/2);
}