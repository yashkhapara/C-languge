#include<stdio.h>
void main()
{
    int a;
    printf("enter the value:");
    scanf("%d",&a);

    printf("weekly salry :%d",a*15);
}