#include<stdio.h>
void main()
{
    int a,b;
    printf("enter the value:\n");
    scanf("%d",&a);
     b=3.14*a*a;
    printf("Area of the circl:%d\n",b);

    printf("PI 3.14159");
}