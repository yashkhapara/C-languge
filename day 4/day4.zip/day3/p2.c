#include<stdio.h>
void main()
{
    int a,b;
    printf("enter the value:");
    scanf("%d",&a);
     b=2*a*3.14;
    printf("Circumference of the circle :%d",b);
}