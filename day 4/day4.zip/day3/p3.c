#include<stdio.h>
void main()
{
    int a,b,c;
    printf("enter the value:");
    scanf("%d%d",&a,&c);
     b=a*c;
    printf("Product of a and c is:%d",b);
}